package provalocadoracarros;

public class CarroIndisponivelException extends RuntimeException{

    public CarroIndisponivelException(String message) {
        super(message);
    }
    
}
