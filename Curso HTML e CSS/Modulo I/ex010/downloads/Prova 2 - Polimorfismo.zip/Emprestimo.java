package provalocadoracarros;

public class Emprestimo {
    private Cliente cliente;
    private Carro carro;
    private int renovacoes;
    private double dividaTotal;

    
    //  CONSTRUTORES
    
    public Emprestimo(PessoaFisica pf, Carro carro, int renovacoes, double dividaTotal) {
        if(pf.getQtdEmprestimos() == 0){
            if(carro.isDisponivel()){
                this.cliente = pf;
                this.carro = carro;
                this.renovacoes = renovacoes;
                this.dividaTotal = dividaTotal;
                this.cliente.setQtdEmprestimos(this.cliente.getQtdEmprestimos() + 1);
                this.carro.setDisponivel(false);
            }
            else{
                throw new CarroIndisponivelException("Carro indisponivel para locacao");
            }
        }
        else{
            throw new MaximoEmprestimosException("Voce nao pode realizar mais de um emprestimo por vez!");
        }
    }

    public Emprestimo(Empresa empresa, Carro carro, int renovacoes, double dividaTotal) {
        if(carro.isDisponivel()){
            this.cliente = empresa;
            this.carro = carro;
            this.renovacoes = renovacoes;
            this.dividaTotal = dividaTotal;
            this.cliente.setQtdEmprestimos(this.cliente.getQtdEmprestimos() + 1);
            this.carro.setDisponivel(false);
        }
        else{
            System.out.println("Carro indisponivel para locacao");
        }
    }
    
    
    // GETTERS & SETTERS

    public Cliente getCliente() {
        return cliente;
    }

    private void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public Carro getCarro() {
        return carro;
    }

    private void setCarro(Carro carro) {
        this.carro = carro;
    }

    public int getRenovacoes() {
        return renovacoes;
    }

    private void setRenovacoes(int renovacoes) {
        this.renovacoes = renovacoes;
    }
    
    private void addRenovacoes(){
        this.renovacoes++;
    }

    public double getDividaTotal() {
        return dividaTotal;
    }

    private void setDividaTotal(double dividaTotal) {
        this.dividaTotal = dividaTotal;
    }
    
    
    //  METODOS ESPECIAIS DE EMPRESTIMO
    
    public void renovarAluguel(){
        this.addRenovacoes();
        
        if(this.renovacoes > this.carro.getCotaRenovacoes()){
            this.dividaTotal++;
        }
    }
    
    public void devolverCarro(){
        if(this.renovacoes > carro.getCotaRenovacoes()){
            this.setDividaTotal((this.dividaTotal * this.carro.getValorMulta()) + this.carro.getValorAlocacao());
            this.setRenovacoes(0);
            this.carro.setDisponivel(true);
            System.out.println("Voce deve uma divida de: RS" + this.dividaTotal);
        }
        else{
            this.setRenovacoes(0);
            this.setDividaTotal(this.carro.getValorAlocacao());
            this.carro.setDisponivel(true);
            System.out.println("Voce deve uma divida de: RS" + this.dividaTotal);
        }
    }
    
    
    
}
