package provalocadoracarros;

public class MaximoEmprestimosException extends RuntimeException {

    public MaximoEmprestimosException(String message) {
        super(message);
    }
    
}
